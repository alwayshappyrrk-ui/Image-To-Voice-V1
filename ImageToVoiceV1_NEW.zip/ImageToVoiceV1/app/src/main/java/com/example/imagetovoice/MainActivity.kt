package com.example.imagetovoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var editText: EditText
    private lateinit var imagePreview: ImageView
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var uri: Uri? = null
    private var bitmap: Bitmap? = null
    private var deep = false
    private var lastFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        imagePreview = findViewById(R.id.imagePreview)
        editText = findViewById(R.id.editText)
        status = findViewById(R.id.status)
        tts = TextToSpeech(this, this)
        findViewById<Button>(R.id.btnGallery).setOnClickListener { gallery() }
        findViewById<Button>(R.id.btnCamera).setOnClickListener { camera() }
        findViewById<Button>(R.id.btnOcr).setOnClickListener { ocr() }
        findViewById<Button>(R.id.btnNormal).setOnClickListener { deep=false; status.text="Normal voice selected" }
        findViewById<Button>(R.id.btnDeep).setOnClickListener { deep=true; status.text="Deep voice selected" }
        findViewById<Button>(R.id.btnPreview).setOnClickListener { preview() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveAudio() }
        findViewById<Button>(R.id.btnShare).setOnClickListener { shareAudio() }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi","IN")
            status.text = "Ready"
        } else status.text = "Text-to-Speech unavailable"
    }

    private fun gallery() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type="image/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }, 100)
    }

    private fun camera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 102)
        } else startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 101)
    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (resultCode != Activity.RESULT_OK) return
        if (requestCode==100) {
            uri=data?.data; bitmap=null; imagePreview.setImageURI(uri)
        } else if (requestCode==101) {
            bitmap=data?.extras?.get("data") as? Bitmap; uri=null; imagePreview.setImageBitmap(bitmap)
        }
        status.text="Image ready"
    }

    private fun ocr() {
        val input = try {
            when {
                uri != null -> InputImage.fromFilePath(this, uri!!)
                bitmap != null -> InputImage.fromBitmap(bitmap!!,0)
                else -> { status.text="Select an image first"; return }
            }
        } catch(e:Exception) { status.text="Could not read image"; return }
        status.text="Reading text..."
        val recognizer=TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        recognizer.process(input).addOnSuccessListener {
            editText.setText(it.text)
            status.text=if(it.text.isBlank()) "No text found" else "Text extracted"
            recognizer.close()
        }.addOnFailureListener {
            status.text="OCR failed"
            recognizer.close()
        }
    }

    private fun voice() {
        tts.setPitch(if(deep) 0.72f else 1f)
        tts.setSpeechRate(if(deep) 0.9f else 1f)
        tts.voices?.firstOrNull { it.locale.language=="hi" && !it.isNetworkConnectionRequired }?.let { tts.voice=it }
    }

    private fun preview() {
        val text=editText.text.toString().trim()
        if(text.isEmpty()){ status.text="Enter text first"; return }
        voice(); tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"preview")
        status.text="Playing..."
    }

    private fun saveAudio() {
        val text=editText.text.toString().trim()
        if(text.isEmpty()){ status.text="Enter text first"; return }
        voice()
        val dir=getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
        dir.mkdirs()
        val file=File(dir,"ImageToVoice_${System.currentTimeMillis()}.wav")
        lastFile=file
        tts.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
            override fun onStart(id:String?){}
            override fun onDone(id:String?){ runOnUiThread { status.text="Saved: ${file.name}" } }
            override fun onError(id:String?){ runOnUiThread { status.text="Audio save failed" } }
        })
        val result=tts.synthesizeToFile(text,Bundle(),file,"save_${System.currentTimeMillis()}")
        if(result!=TextToSpeech.SUCCESS) status.text="Save request failed" else status.text="Saving audio..."
    }

    private fun shareAudio() {
        val f=lastFile
        if(f==null || !f.exists()){ status.text="Save audio first"; return }
        val u=androidx.core.content.FileProvider.getUriForFile(this,"${packageName}.fileprovider",f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type="audio/wav"; putExtra(Intent.EXTRA_STREAM,u)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        },"Share Audio"))
    }

    override fun onDestroy(){ tts.stop(); tts.shutdown(); super.onDestroy() }
}
