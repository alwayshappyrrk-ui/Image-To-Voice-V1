# ImageToVoiceV1

Image → OCR text → edit → voice → preview → save/download audio.

Features:
- Camera and Gallery image selection
- Devanagari OCR
- Editable extracted text
- Normal and Deep voice presets
- Voice preview
- Save generated audio as WAV
- Share saved audio
