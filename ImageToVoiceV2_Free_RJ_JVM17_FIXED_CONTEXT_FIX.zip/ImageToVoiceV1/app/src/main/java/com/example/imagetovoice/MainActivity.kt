package com.example.imagetovoice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var editText: EditText
    private lateinit var status: TextView
    private lateinit var spinnerVoice: Spinner
    private lateinit var spinnerStyle: Spinner
    private lateinit var tts: TextToSpeech
    private val voices = mutableListOf<Voice>()
    private val voiceLabels = mutableListOf<String>()
    private var selectedGender = "female"

    private val gallery = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let { runOcr(it) } }
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { it?.let { runOcr(InputImage.fromBitmap(it, 0)) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        editText = findViewById(R.id.editText)
        status = findViewById(R.id.status)
        spinnerVoice = findViewById(R.id.spinnerVoice)
        spinnerStyle = findViewById(R.id.spinnerStyle)
        tts = TextToSpeech(this, this)

        spinnerStyle.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("RJ Natural", "RJ Energetic", "Calm Announcement"))
        findViewById<Button>(R.id.btnGallery).setOnClickListener { gallery.launch("image/*") }
        findViewById<Button>(R.id.btnCamera).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 10) else camera.launch(null)
        }
        findViewById<Button>(R.id.btnFemale).setOnClickListener { selectGender("female") }
        findViewById<Button>(R.id.btnMale).setOnClickListener { selectGender("male") }
        findViewById<Button>(R.id.btnPlay).setOnClickListener { speak() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { tts.stop(); status.text = "Voice stopped" }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveAudio() }
    }

    private fun runOcr(uri: Uri) { status.text = "Text read होत आहे..."; try { runOcr(InputImage.fromFilePath(this, uri)) } catch (_: Exception) { status.text = "Image उघडता आली नाही." } }
    private fun runOcr(image: InputImage) {
        val r = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        r.process(image).addOnSuccessListener { editText.setText(it.text); status.text = if (it.text.isBlank()) "Text सापडला नाही." else "Text तयार आहे."; r.close() }
            .addOnFailureListener { status.text = "OCR error: ${it.message}"; r.close() }
    }

    override fun onInit(result: Int) {
        if (result != TextToSpeech.SUCCESS) { status.text = "TTS engine unavailable"; return }
        val mr = Locale("mr", "IN")
        val available = tts.isLanguageAvailable(mr)
        if (available >= TextToSpeech.LANG_AVAILABLE) tts.language = mr else tts.language = Locale("hi", "IN")
        loadVoices()
        status.text = "Free RJ Voice engine ready"
    }

    private fun loadVoices() {
        voices.clear(); voiceLabels.clear()
        val all = tts.voices ?: emptySet()
        val candidates = all.filter { v ->
            val l = v.locale.language.lowercase(Locale.US)
            l == "mr" || l == "hi" || l == "en"
        }.sortedWith(compareBy<Voice>({ !it.locale.language.equals("mr", true) }, { it.name }))
        val usable = if (candidates.isNotEmpty()) candidates else all.toList()
        usable.forEach { v ->
            if (!v.isNetworkConnectionRequired) {
                voices.add(v)
                voiceLabels.add(labelFor(v))
            }
        }
        if (voiceLabels.isEmpty()) { voices.addAll(usable); voiceLabels.addAll(usable.map { labelFor(it) }) }
        spinnerVoice.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, voiceLabels)
        selectGender("female")
    }

    private fun labelFor(v: Voice): String {
        val n = v.name.lowercase(Locale.US)
        val gender = when { n.contains("female") || n.contains("woman") || n.contains("fem") -> "Female"; n.contains("male") || n.contains("man") -> "Male"; else -> "Voice" }
        return "$gender • ${v.locale.displayName} • ${v.name}"
    }

    private fun selectGender(gender: String) {
        selectedGender = gender
        val index = voices.indexOfFirst { n ->
            val s = n.name.lowercase(Locale.US)
            if (gender == "female") s.contains("female") || s.contains("woman") || s.contains("fem")
            else s.contains("male") || s.contains("man")
        }
        if (index >= 0) spinnerVoice.setSelection(index)
        status.text = if (index >= 0) "${gender.replaceFirstChar { it.uppercase() }} RJ voice selected" else "No separate $gender voice found; using installed TTS voice"
    }

    private fun configureVoice() {
        val i = spinnerVoice.selectedItemPosition
        if (i in voices.indices) tts.voice = voices[i]
        val style = spinnerStyle.selectedItem?.toString() ?: "RJ Natural"
        when (style) {
            "RJ Energetic" -> { tts.setSpeechRate(1.02f); tts.setPitch(if (selectedGender == "male") 0.92f else 1.03f) }
            "Calm Announcement" -> { tts.setSpeechRate(0.86f); tts.setPitch(if (selectedGender == "male") 0.94f else 1.02f) }
            else -> { tts.setSpeechRate(0.92f); tts.setPitch(if (selectedGender == "male") 0.96f else 1.02f) }
        }
    }

    private fun rjText(raw: String): String {
        return raw.trim()
            .replace(Regex("[ \t]+"), " ")
            .replace(Regex("([.!?।])\\s*"), "$1  ")
            .replace(Regex("[,，]\\s*"), ", ")
    }

    private fun speak() {
        val s = editText.text.toString().trim()
        if (s.isEmpty()) { status.text = "आधी फोटोमधून Text घ्या."; return }
        configureVoice()
        tts.speak(rjText(s), TextToSpeech.QUEUE_FLUSH, null, "rj_preview")
        status.text = "RJ voice playing..."
    }

    private fun saveAudio() {
        val s = editText.text.toString().trim()
        if (s.isEmpty()) { status.text = "आधी Text तयार करा."; return }
        configureVoice()
        val dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
        val file = File(dir, "ImageToVoice_RJ_${System.currentTimeMillis()}.wav")
        val result = tts.synthesizeToFile(rjText(s), null, file, "rj_saved")
        if (result == TextToSpeech.SUCCESS) {
            status.text = "Audio saved: ${file.name}"
            MediaScannerConnection.scanFile(this, arrayOf(file.absolutePath), arrayOf("audio/wav"), null)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "audio/wav"
                putExtra(
                    Intent.EXTRA_STREAM,
                    androidx.core.content.FileProvider.getUriForFile(
                        this@MainActivity,
                        "${packageName}.fileprovider",
                        file
                    )
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(Intent.createChooser(share, "Share saved audio")) } catch (_: Exception) { }
        } else status.text = "Audio save failed"
    }

    override fun onDestroy() { tts.stop(); tts.shutdown(); super.onDestroy() }
}
