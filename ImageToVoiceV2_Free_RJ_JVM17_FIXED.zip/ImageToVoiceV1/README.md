# ImageToVoice V2

Free Android Image → Voice app.

## V2 changes
- No paid TTS API, API key or billing.
- Uses the Android device's installed Text-to-Speech engine.
- Detects installed Marathi/Hindi/English voices and lets the user choose an available voice.
- Female RJ / Male RJ quick selection when the installed engine exposes a matching voice.
- RJ Natural, RJ Energetic and Calm Announcement styles.
- More natural speech rate/pitch defaults and punctuation-based pauses.
- Play, Stop and Save Audio actions.
- OCR remains powered by Google ML Kit Devanagari text recognition.

### Important
Voice quality depends on the TTS engine and voices installed on the Android phone. This V2 intentionally does not use a cloud/neural TTS API, so there is no usage charge from the app.
