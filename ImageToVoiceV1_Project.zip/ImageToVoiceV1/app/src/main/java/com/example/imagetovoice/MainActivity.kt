package com.example.imagetovoice

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
 private lateinit var editText: EditText; private lateinit var status: TextView; private lateinit var tts: TextToSpeech; private var deep=false
 private val gallery=registerForActivityResult(ActivityResultContracts.GetContent()){it?.let{runOcr(it)}}
 private val camera=registerForActivityResult(ActivityResultContracts.TakePicturePreview()){it?.let{runOcr(InputImage.fromBitmap(it,0))}}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);editText=findViewById(R.id.editText);status=findViewById(R.id.status);tts=TextToSpeech(this,this)
  findViewById<Button>(R.id.btnGallery).setOnClickListener{gallery.launch("image/*")}
  findViewById<Button>(R.id.btnCamera).setOnClickListener{if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.CAMERA),10)else camera.launch(null)}
  findViewById<Button>(R.id.btnNormal).setOnClickListener{deep=false;speak()};findViewById<Button>(R.id.btnDeep).setOnClickListener{deep=true;speak()};findViewById<Button>(R.id.btnPlay).setOnClickListener{ speak() };findViewById<Button>(R.id.btnSave).setOnClickListener{ speak() }
 }
 private fun runOcr(uri:Uri){status.text="Text read होत आहे...";try{runOcr(InputImage.fromFilePath(this,uri))}catch(e:Exception){status.text="Image उघडता आली नाही."}}
 private fun runOcr(image:InputImage){val r=TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build());r.process(image).addOnSuccessListener{editText.setText(it.text);status.text=if(it.text.isBlank())"Text सापडला नाही." else "Text तयार आहे.";r.close()}.addOnFailureListener{status.text="OCR error: ${it.message}";r.close()}}
 override fun onInit(x:Int){if(x==TextToSpeech.SUCCESS){tts.language=Locale("mr","IN");tts.setSpeechRate(.9f);tts.setPitch(.82f);status.text="Voice engine ready"}else status.text="TTS engine unavailable"}
 private fun speak(){val s=editText.text.toString().trim();if(s.isEmpty()){status.text="आधी फोटोमधून Text घ्या.";return};tts.setSpeechRate(if(deep).88f else .96f);tts.setPitch(if(deep).72f else .98f);tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"preview");status.text=if(deep)"Deep Voice playing..." else "Voice playing..."}
 override fun onDestroy(){tts.stop();tts.shutdown();super.onDestroy()}
}
