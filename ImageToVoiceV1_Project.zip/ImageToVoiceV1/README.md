# Image To Voice V1
Camera/Gallery -> Devanagari OCR -> Editable Text -> Normal/Deep TTS.
OCR is local/free. Deep mode lowers TTS pitch. Proper MP3 encoding and Save/Share are planned for V2; WAV must not simply be renamed to MP3.
